#!/bin/sh

echo convert .ui to .py
pyuic5 -o form.py form.ui

