# -*- coding: utf-8 -*-
##################################
#
#	 library
#
##################################
import os, sys, signal, threading
#********************************
#  data construct
#********************************
import myData.myData as md
import myData.myDataProcess as mdp
import myData.myItem as mi
#********************************
#  ROS
#********************************
import rospy, tf
from visualization_msgs.msg import MarkerArray
from moveit_msgs.msg import DisplayTrajectory
from gui_form.srv import *
from std_srvs.srv import *

#********************************
#  Qt
#********************************
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui
from form import Ui_MainWindow
from qt.tw_module import *
from qt.popUpDialog import *
import myData.myItem as mi

############################################
#
# Threading
#
############################################
std_lock = threading.Lock()
class pub_thread(threading.Thread):
  # ******************************
  #
  #  constructor
  #
  # ******************************
  def __init__(self, std_lock, master):
    super(pub_thread, self).__init__()
    self.daemon = True
    self.std_lock = std_lock
    self.master = master
    
  # ******************************
  #
  #  thread execution
  #
  # ******************************
  def run(self):
    while True:
      with self.std_lock:
        pnt = self.master.dat.get("points")
        p   = pnt.get(str(item.text(0)))
        mi.tableAxes(p.get("table"), x=0, y=0, z=0.1)
        array = mi.workMarker(self.master.dat.get("item"), p)
        

