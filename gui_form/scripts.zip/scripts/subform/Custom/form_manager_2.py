# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui
import popUpDialog.Custom.form as f1
import popUpDialog.Custom.form2 as f2

#import rospy
#from sensor_msgs.msg import JointState
from gui_sample.srv import *
from tw.myTreewidget import *
from spinBox.infSpinBox import *

from datDef import *

#from time import sleep
#####################################
#
#	 Sub functions
#
#####################################
def setRange(ui, Vmin, Vmax, Vstep, ratio=1.0):
  ui.setRange(Vmin*ratio, Vmax*ratio)
  ui.setSingleStep(Vstep*ratio)

def str2float(s):
  s = s.replace('[', '').replace(']', '')
  s = s.split(',')
  f = [float(v) for v in s]
  return f
  
#####################################
#
# Sub form_manager
#
#####################################
class subform_manager(QDialog):
  def __init__(self, parent=None, pos=None):
  # ******************************
  #
  #  constructor
  #
  # ******************************
    super(subform_manager, self).__init__()
    self.parent = parent
    self.ui = f2.Ui_Dialog()
    self.ui.setupUi(self)
    
    # groupBox
    self.ui.groupBox.setTitle("Size")
    self.ui.groupBox_2.setTitle("Offset")

    # label
    self.ui.label.setText('X [mm]')
    self.ui.label_2.setText('Y [mm]')
    self.ui.label_3.setText('Z [mm]')
    self.ui.label_4.setText('X [mm]')
    self.ui.label_5.setText('Y [mm]')

    # doubleSpinBox
    self.ui.doubleSpinBox.setRange(0.0, 300.00)
    self.ui.doubleSpinBox_2.setRange(0.0, 300.00)
    self.ui.doubleSpinBox_3.setRange(0.0, 300.00)
    self.ui.doubleSpinBox_4.setRange(0.0, 300.00)
    self.ui.doubleSpinBox_5.setRange(0.0, 300.00)

    if self.parent is not None:
      self.ui.doubleSpinBox.setValue(self.parent.work.size[0])
      self.ui.doubleSpinBox_2.setValue(self.parent.work.size[1])
      self.ui.doubleSpinBox_3.setValue(self.parent.work.size[2])
      self.ui.doubleSpinBox_4.setValue(self.parent.work.offset[0])
      self.ui.doubleSpinBox_5.setValue(self.parent.work.offset[1])

    self.setWindowFlags(QtCore.Qt.Popup)
    self.show()
    
    if pos is not None:
      self.move(pos)

  # ******************************
  #
  #  destructor
  #
  # ******************************
  def __del__(self):
    print "[subform_manager] delete subform_manager"

  # ******************************
  #
  #  close event
  #
  # ******************************
  def closeEvent(self,e):
    size   = [self.ui.doubleSpinBox.value(),
              self.ui.doubleSpinBox_2.value(),
              self.ui.doubleSpinBox_3.value()]
    offset = [self.ui.doubleSpinBox_4.value(),
              self.ui.doubleSpinBox_5.value()]
    if self.parent is not None:
      self.parent.work.size = size
      self.parent.work.offset = offset
    
#####################################
#
# form_manager
#
#  * parent must have [createSub] member
#
#####################################
class form_manager(QDialog):
  # ******************************
  #
  #  constructor
  #
  # ******************************
  def __init__(self, parent=None, idx=0):
    super(form_manager, self).__init__()
    self.parent = parent  # Parent dialog
    self.ui = f1.Ui_Dialog()
    self.work = self.parent.data.work.clone()
    self.pnt  = self.parent.data.pnt[idx].clone()
    self.idx  = idx
  # ******************************
  #
  #  destructor
  #
  # ******************************
  def __del__(self):
    print "[form_manager] delete form_manager"

  # ******************************
  #
  #  stop UI
  #
  # ******************************
  def stopUi(self):
    self.parent.createSub = False
    
  # ******************************
  #
  #  preset UI
  #
  # ******************************
  def setupUi(self,Form):
    #	Cancel the top display setting of the parent dialog
    self.parent.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, False)
    self.parent.show()

    self.ui.setupUi(Form)

    # ==============================
    #  Qdialog setting
    # ==============================
    style = QApplication.instance().style()
    self.ratio = 0.01
    self.Form = Form              # f1 form    
    self.size = Form.size()
    self.sub  = subform_manager() # f2 form
    
    self.preset_tab1()
    self.preset_tab2()
    
    # button
    self.ui.pushButton.clicked.connect(self.reset_button_click)
    self.ui.pushButton.setText('Reset')
    self.ui.pushButton_2.clicked.connect(self.save_button_click)
    self.ui.pushButton_2.setText('Save')

    # tool button
    self.ui.toolButton.clicked.connect(self.tool_click)


  # ******************************
  # 
  # preset tab1
  #  * groupBox      : 4,5,6
  #  * comboBox      : 1,2
  #  * spinBox       : 1,2,3,4
  #  * doubleSpinBox : 8,9
  #  * label         : 8,9,10,11,12,13,14,15
  #
  # ******************************
  def preset_tab1(self):
    # groupBox
    self.ui.groupBox_4.setTitle("")
    self.ui.groupBox_5.setTitle("")
    self.ui.groupBox_6.setTitle("")
    self.ui.groupBox_6.setEnabled(False)
    
    # comboBox
    self.boxList1 = ["GRID", "DIRECT"]
    self.boxList2 = ["+ Z", "+ X", "- X", "+ Y", "- Y"]
    for l in self.boxList1:
      self.ui.comboBox.addItem(l)
    for l in self.boxList2:
      self.ui.comboBox_2.addItem(l)
    
    # label
    self.ui.label_8.setText('Mode')
    self.ui.label_9.setText('Surface')
    self.ui.label_10.setText('Number of rows')
    self.ui.label_11.setText('Number of columns')
    self.ui.label_12.setText('Row index')
    self.ui.label_13.setText('Column index')
    self.ui.label_14.setText('Y (row)')
    self.ui.label_15.setText('X (column)')

    # spinBox
    self.set_tab1_Range()   
    
    # signals
    self.ui.comboBox.activated.connect(self.tab1Changed)
    self.ui.comboBox_2.activated.connect(self.tab1Changed)
    self.ui.spinBox.valueChanged.connect(self.tab1Changed)
    self.ui.spinBox_2.valueChanged.connect(self.tab1Changed)
    self.ui.spinBox_3.valueChanged.connect(self.tab1Changed)
    self.ui.spinBox_4.valueChanged.connect(self.tab1Changed)
    self.ui.doubleSpinBox_8.valueChanged.connect(self.tab1Changed)
    self.ui.doubleSpinBox_9.valueChanged.connect(self.tab1Changed)
    
    # initial value
    self.set_tab1()

  # ******************************
  # 
  # preset tab2
  #  * groupBox         : 1,2,3
  #  * doubleSpinBox    : 1,2,4,5,6,7
  #  * horizontalSlider : 1,2,4,5,6,7
  #  * label            : 1,2,4,5,6,7
  #
  # ******************************
  def preset_tab2(self):
    # group box
    self.ui.groupBox.setTitle("robot1")
    self.ui.groupBox_2.setTitle("robot2")
    self.ui.groupBox_3.setTitle("table")

    # label
    self.ui.label.setText('D [mm]')
    self.ui.label_2.setText('P [deg]')
    self.ui.label_3.setText('T [deg]')
    self.ui.label_4.setText('D [mm]')
    self.ui.label_5.setText('P [deg]')
    self.ui.label_6.setText('T [deg]')
    self.ui.label_7.setText('θ [deg]')
    
    # spinBox
    self.ui.doubleSpinBox.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_2.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_3.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_4.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_5.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_6.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_7.valueChanged.connect(self.doubleSpinChanged)
    
    # slider
    self.ui.horizontalSlider.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_2.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_3.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_4.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_5.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_6.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_7.valueChanged.connect(self.sliderChanged)
 
    self.setRange([  0.0,   0.0, -90.0,   0.0,   0.0, -90.0,   0.0],
                  [400.0,  90.0,  90.0, 400.0,  90.0,  90.0, 360.0],
                  [  1.0,   1.0,   1.0,   1.0,   1.0,   1.0,   1.0])

  #**********************************
  #
  # Block signal
  #
  #**********************************
  def block_tab1_Signal(self, on):
    self.ui.comboBox.blockSignals(on)
    self.ui.comboBox_2.blockSignals(on)
    self.ui.spinBox.blockSignals(on)
    self.ui.spinBox_2.blockSignals(on)
    self.ui.spinBox_3.blockSignals(on)
    self.ui.spinBox_4.blockSignals(on)
    self.ui.doubleSpinBox_8.blockSignals(on)
    self.ui.doubleSpinBox_9.blockSignals(on)
    
  def block_tab2_Signal(self, on):
    self.ui.doubleSpinBox.blockSignals(on)
    self.ui.doubleSpinBox_2.blockSignals(on)
    self.ui.doubleSpinBox_3.blockSignals(on)
    self.ui.doubleSpinBox_4.blockSignals(on)
    self.ui.doubleSpinBox_5.blockSignals(on)
    self.ui.doubleSpinBox_6.blockSignals(on)
    self.ui.doubleSpinBox_7.blockSignals(on)
    self.ui.horizontalSlider.blockSignals(on)
    self.ui.horizontalSlider_2.blockSignals(on)
    self.ui.horizontalSlider_3.blockSignals(on)
    self.ui.horizontalSlider_4.blockSignals(on)
    self.ui.horizontalSlider_5.blockSignals(on)
    self.ui.horizontalSlider_6.blockSignals(on)
    self.ui.horizontalSlider_7.blockSignals(on)
   
  # ******************************
  # 
  # set tab1
  #
  # ******************************
  def set_tab1(self):
    self.block_tab1_Signal(True)
    self.ui.comboBox.setCurrentIndex(self.pnt.mode)
    self.ui.comboBox_2.setCurrentIndex(self.pnt.surface)
    self.ui.spinBox.setValue(self.pnt.Nrows)
    self.ui.spinBox_2.setValue(self.pnt.Ncols)
    self.ui.spinBox_3.setValue(self.pnt.Idxrow)
    self.ui.spinBox_4.setValue(self.pnt.Idxcol)
    self.set_tab1_group(self.pnt.mode)

    x,y = calcData(self.pnt, self.work)
    if x is not None:
      self.pnt.Y = y
      self.pnt.X = x
    
    self.ui.doubleSpinBox_8.setValue(self.pnt.Y)
    self.ui.doubleSpinBox_9.setValue(self.pnt.X)
    self.block_tab1_Signal(False)
  # ******************************
  # 
  # set tab1 group
  #
  # ******************************
  def set_tab1_group(self, idx):
    if idx == 0:
      self.ui.groupBox_5.setEnabled(True)
      self.ui.groupBox_6.setEnabled(False)
    elif idx == 1:
      self.ui.groupBox_5.setEnabled(False)
      self.ui.groupBox_6.setEnabled(True)
      
  # ******************************
  # 
  # get tab1
  #
  # ******************************    
  def get_tab1(self):
    self.block_tab1_Signal(True)

    self.pnt.mode    = self.ui.comboBox.currentIndex()
    self.pnt.surface = self.ui.comboBox_2.currentIndex()
    self.pnt.Nrows   = self.ui.spinBox.value()
    self.pnt.Ncols   = self.ui.spinBox_2.value()
    self.pnt.Idxrow  = self.ui.spinBox_3.value()
    self.pnt.Idxcol  = self.ui.spinBox_4.value()

    # GRID -> DIRECT
    x,y = calcData(self.pnt, self.work)
    if x is not None:
      self.ui.doubleSpinBox_8.setValue(y)
      self.ui.doubleSpinBox_9.setValue(x) 

    self.pnt.Y       = self.ui.doubleSpinBox_8.value()
    self.pnt.X       = self.ui.doubleSpinBox_9.value()
    self.block_tab1_Signal(False)
  
  # ******************************
  # (SIGNAL)
  # tab1 widget changed
  #
  # ******************************
  def tab1Changed(self,idx):
    obj = self.sender()
    self.set_tab1_Range()
    print "change"

    if obj is self.ui.comboBox:
      self.set_tab1_group(idx)

    self.get_tab1()
  # ******************************
  # (SIGNAL)
  # tab2 widget changed
  #
  # ******************************
  def doubleSpinChanged(self):
    self.value_changed()  # SpinBox -> Slider
  def sliderChanged(self):
    self.value_changed2() # Slider -> SpinBox
    
  # ******************************
  # (SIGNAL)
  # reset button clicked
  #
  # ******************************
  def reset_button_click(self):
    self.work = self.parent.data.work.clone()
    self.pnt  = self.parent.data.pnt[self.idx].clone()
    self.set_tab1() 
  # ******************************
  # (SIGNAL)
  # save button clicked
  #
  # ******************************
  def save_button_click(self):
    self.parent.data.work = self.work.clone()
    self.parent.data.pnt[self.idx] = self.pnt.clone() 
  # ******************************
  # (SIGNAL)
  # tool button clicked
  #
  # ******************************
  def tool_click(self):
    pos  = self.Form.pos()
    qPos = pos + QtCore.QPoint(int(self.size.width()/7), int(self.size.height()/4))
    self.sub = subform_manager(self, qPos)

  # ******************************
  #
  # update tab2 (SpinBox -> Slider)
  #
  # ******************************
  def value_changed(self):
    self.block_tab2_Signal(True)
    self.ui.horizontalSlider.setValue(self.ui.doubleSpinBox.value()/self.ratio)
    self.ui.horizontalSlider_2.setValue(self.ui.doubleSpinBox_2.value()/self.ratio)
    self.ui.horizontalSlider_3.setValue(self.ui.doubleSpinBox_3.value()/self.ratio)
    self.ui.horizontalSlider_4.setValue(self.ui.doubleSpinBox_4.value()/self.ratio)
    self.ui.horizontalSlider_5.setValue(self.ui.doubleSpinBox_5.value()/self.ratio)
    self.ui.horizontalSlider_6.setValue(self.ui.doubleSpinBox_6.value()/self.ratio)
    self.ui.horizontalSlider_7.setValue(self.ui.doubleSpinBox_7.value()/self.ratio)
    self.block_tab2_Signal(False)

  # ******************************
  #
  # update tab2 (Slider -> SpinBox)
  #
  # ******************************
  def value_changed2(self):
    self.block_tab2_Signal(True)
    self.ui.doubleSpinBox.setValue(self.ui.horizontalSlider.value()*self.ratio)
    self.ui.doubleSpinBox_2.setValue(self.ui.horizontalSlider_2.value()*self.ratio)
    self.ui.doubleSpinBox_3.setValue(self.ui.horizontalSlider_3.value()*self.ratio)
    self.ui.doubleSpinBox_4.setValue(self.ui.horizontalSlider_4.value()*self.ratio)
    self.ui.doubleSpinBox_5.setValue(self.ui.horizontalSlider_5.value()*self.ratio)
    self.ui.doubleSpinBox_6.setValue(self.ui.horizontalSlider_6.value()*self.ratio)
    self.ui.doubleSpinBox_7.setValue(self.ui.horizontalSlider_7.value()*self.ratio)
    self.block_tab2_Signal(False)
   
  #**********************************
  #
  # Set range and step size
  #
  #**********************************
  def setRange(self, Vmin=[0.0]*7, Vmax=[1.0]*7, Vstep=[0.01]*7):
    if (len(Vmin) == 7) and (len(Vmax) == 7) and (len(Vstep) == 7):
      setRange(self.ui.doubleSpinBox,   Vmin[0], Vmax[0], Vstep[0])
      setRange(self.ui.doubleSpinBox_2, Vmin[1], Vmax[1], Vstep[1])
      setRange(self.ui.doubleSpinBox_3, Vmin[2], Vmax[2], Vstep[2])
      setRange(self.ui.doubleSpinBox_4, Vmin[3], Vmax[3], Vstep[3])
      setRange(self.ui.doubleSpinBox_5, Vmin[4], Vmax[4], Vstep[4])
      setRange(self.ui.doubleSpinBox_6, Vmin[5], Vmax[5], Vstep[5])
      setRange(self.ui.doubleSpinBox_7, Vmin[6], Vmax[6], Vstep[6])

      R = 1.0/self.ratio
      setRange(self.ui.horizontalSlider,   Vmin[0], Vmax[0], Vstep[0], R)
      setRange(self.ui.horizontalSlider_2, Vmin[1], Vmax[1], Vstep[1], R)
      setRange(self.ui.horizontalSlider_3, Vmin[2], Vmax[2], Vstep[2], R)
      setRange(self.ui.horizontalSlider_4, Vmin[3], Vmax[3], Vstep[3], R)
      setRange(self.ui.horizontalSlider_5, Vmin[4], Vmax[4], Vstep[4], R)
      setRange(self.ui.horizontalSlider_6, Vmin[5], Vmax[5], Vstep[5], R)
      setRange(self.ui.horizontalSlider_7, Vmin[6], Vmax[6], Vstep[6], R)

  #**********************************
  #
  # Set range2
  #
  #**********************************
  def set_tab1_Range(self):
    setRange(self.ui.doubleSpinBox_8, 0.0, 300.0, 1.0, ratio=1.0)
    setRange(self.ui.doubleSpinBox_9, 0.0, 300.0, 1.0, ratio=1.0)
    setRange(self.ui.spinBox,   1, 300, 1)
    setRange(self.ui.spinBox_2, 1, 300, 1)
    setRange(self.ui.spinBox_3, 0, self.ui.spinBox.value()-1,1)
    setRange(self.ui.spinBox_4, 0, self.ui.spinBox_2.value()-1,1)

  #**********************************
  #
  # send value to parent
  #
  #**********************************
  def sendToParent(self, intype=0, outtype=0):
    #===========================
    # Request
    #===========================
    req = stateCmdRequest()
    req.mechno  = 1
    req.val     = 0
    req.flg     = 0
    req.inType  = intype      # 0:jnt 1:pos 
    req.outType = outtype     # 0:jnt 1:pos 

    #===========================
    # Response
    #===========================
    res = self.parent.sendToServer(req)
    if res.result==0: #OK
      #self.val = list(res.val)
      #self.flg = list(res.flg)
      #return self.val
      pass
    else:             #NG
      #self.setValue(self.val)
      return None
      
 
