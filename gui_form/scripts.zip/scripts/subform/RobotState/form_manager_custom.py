# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui
import popUpDialog.RobotState.form as f1
import popUpDialog.RobotState.form2 as f2

#import rospy
#from sensor_msgs.msg import JointState
from gui_sample.srv import *
from tw.myTreewidget import *
from spinBox.infSpinBox import *


#from time import sleep
#####################################
#
#	 Sub functions
#
#####################################
def setRange(ui, Vmin, Vmax, Vstep, ratio=1.0):
  ui.setRange(Vmin*ratio, Vmax*ratio)
  ui.setSingleStep(Vstep*ratio)

def str2float(s):
  s = s.replace('[', '').replace(']', '')
  s = s.split(',')
  f = [float(v) for v in s]
  return f
  
#####################################
#
# Sub form_manager
#
#####################################
class subform_manager(QDialog):
  def __init__(self, parent=None, init=[False]*3, pos=None):
  # ******************************
  #
  #  constructor
  #
  # ******************************
    super(subform_manager, self).__init__()
    self.parent = parent
    self.ui = f2.Ui_Dialog()
    self.ui.setupUi(self)
    
    self.ui.groupBox.setTitle("Above/Below")
    self.ui.groupBox_2.setTitle("Right/Left")
    self.ui.groupBox_3.setTitle("Flip/NonFlip")
    self.ui.radioButton.setText("Above")
    self.ui.radioButton_2.setText("Below")
    self.ui.radioButton_3.setText("Right")
    self.ui.radioButton_4.setText("Left")
    self.ui.radioButton_5.setText("Flip")
    self.ui.radioButton_6.setText("Nonflip")

    # set initial value
    if len(init) != 3:
      init = [False]*3
      
    if init[0]==False:
      self.ui.radioButton.setChecked(True)
    else:
      self.ui.radioButton_2.setChecked(True)
    if init[1]==False:
      self.ui.radioButton_3.setChecked(True)
    else:
      self.ui.radioButton_4.setChecked(True)
    if init[2]==False:
      self.ui.radioButton_5.setChecked(True)
    else:
      self.ui.radioButton_6.setChecked(True)

    self.setWindowFlags(QtCore.Qt.Popup)
    self.show()
    
    if pos is not None:
      self.move(pos)

  # ******************************
  #
  #  destructor
  #
  # ******************************
  def __del__(self):
    print "[subform_manager] delete subform_manager"

  # ******************************
  #
  #  close event
  #
  # ******************************
  def closeEvent(self,e):
    AB = self.ui.radioButton_2.isChecked()
    RL = self.ui.radioButton_4.isChecked()
    FN = self.ui.radioButton_6.isChecked()
    if self.parent is not None:
      self.parent.flg = [AB,RL,FN]
      self.parent.sendToParent(1,1)
      
#####################################
#
# form_manager
#
#  * parent must have [createSub] member
#
#####################################
class form_manager(QDialog):
  # ******************************
  #
  #  constructor
  #
  # ******************************
  def __init__(self, parent=None):
    super(form_manager, self).__init__()
    self.parent = parent  # Parent dialog
    self.ui = f1.Ui_Dialog()
    self.val = [0.0]*8
    self.flg = [False]*3
    self.boxList = ["CUSTOM","JOINT","POSE"]
    
  # ******************************
  #
  #  destructor
  #
  # ******************************
  def __del__(self):
    print "[form_manager] delete form_manager"

  # ******************************
  #
  #  stop UI
  #
  # ******************************
  def stopUi(self):
    #self.parent.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, True)
    #self.parent.show()
    self.timer.stop()
    self.parent.createSub = False
    
  # ******************************
  #
  #  preset UI
  #
  # ******************************
  def setupUi(self,Form):
    #	Cancel the top display setting of the parent dialog
    self.parent.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, False)
    self.parent.show()

    self.ui.setupUi(Form)

    # ==============================
    #  Qdialog setting
    # ==============================
    style = QApplication.instance().style()
    self.ratio = 0.01
    self.Form = Form             # f1 form    
    self.size = Form.size()
    self.sub = subform_manager() # f2 form

    # group box
    self.ui.groupBox.setTitle("")
    
    # spinBox
    #self.ui.doubleSpinBox = InftyDoubleSpinBox(self.ui.doubleSpinBox)
    self.ui.doubleSpinBox.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_2.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_3.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_4.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_5.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_6.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_7.valueChanged.connect(self.doubleSpinChanged)
    self.ui.doubleSpinBox_8.valueChanged.connect(self.doubleSpinChanged)

    # slider
    self.ui.horizontalSlider.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_2.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_3.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_4.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_5.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_6.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_7.valueChanged.connect(self.sliderChanged)
    self.ui.horizontalSlider_8.valueChanged.connect(self.sliderChanged)
    
    # comboBox
    self.ui.comboBox.activated.connect(self.commboBox_change)
    for i in self.boxList:
      self.ui.comboBox.addItem(i)

    # label
    self.setLabel_custom()

    # button
    self.ui.pushButton.clicked.connect(self.reset_button_click)
    self.ui.pushButton.setText('Reset')
    self.ui.pushButton_2.clicked.connect(self.save_button_click)
    self.ui.pushButton_2.setText('Save')

    # tool button
    self.ui.toolButton.setToolTip('Flag config')
    self.ui.toolButton.setEnabled(False)
    self.ui.toolButton.clicked.connect(self.tool_click)


    # timer
    self.tim = 0
    self.timer = QtCore.QTimer(self)
    #self.timer.timeout.connect(self.upDate)	# Interval function
    #self.timer.start(10)										# msec
  
  # ******************************
  # (SIGNAL)
  # timer interrupted
  #
  # ******************************
  def upDate(self):
    self.tim = self.tim + 1
    if (self.tim % 100) == 0:
      print self.tim//100
  # ******************************
  # (SIGNAL)
  # tool button clicked
  #
  # ******************************
  def tool_click(self):
    pos  = self.Form.pos()
    qPos = pos + QtCore.QPoint(0, self.size.height())
    self.sub = subform_manager(self, self.flg, qPos)
  # ******************************
  # (SIGNAL)
  # commboBox changed
  #
  # ******************************
  def commboBox_change(self):
    if self.isJoint():
      self.ui.toolButton.setEnabled(False)
      self.setLabel_joint()
      self.sendToParent(1,0) # POSE -> JOINT
    elif self.isPose():
      self.ui.toolButton.setEnabled(True)
      self.setLabel_pose()
      self.sendToParent(0,1) # JOINT -> POSE
    elif self.isCustom():
      self.ui.toolButton.setEnabled(True)
      self.setLabel_custom()
    
    self.setValue(self.val)
  # ******************************
  # (SIGNAL)
  # doubleSpinBox Changed
  #
  # ******************************
  def doubleSpinChanged(self):
    self.value_changed() # SpinBox -> Slider
    if self.isJoint():
      self.sendToParent(0,0)
    elif self.isPose():
      self.sendToParent(1,1)
  # ******************************
  # (SIGNAL)
  # horizontalSliber Changed
  #
  # ******************************
  def sliderChanged(self):
    self.value_changed2() #  Slider -> SpinBox
    if self.isJoint():
      self.sendToParent(0,0)
    elif self.isPose():
      self.sendToParent(1,1)
  # ******************************
  # (SIGNAL)
  # reset button clicked
  #
  # ******************************
  def reset_button_click(self):
    tw = self.parent.ui.treeWidget
    item = tw.currentItem()
    if isParent(tw)==False:
      self.setJoint(str(item.text(1)))
  # ******************************
  # (SIGNAL)
  # save button clicked
  #
  # ******************************
  def save_button_click(self):
    if self.isJoint():
      val = self.getValue()
    elif self.isPose():
      val = self.sendToParent(1, 0)
    
    tw = self.parent.ui.treeWidget
    item = tw.currentItem()
    if isParent(tw)==False:
      item.setText(1,str(val))        
    #ret = QInputDialog.getDouble(self,'test','test2',0,0,100,2)
  #**********************************
  #
  # Get current comboBox type
  #
  #**********************************
  def isJoint(self):
    idx = self.ui.comboBox.currentIndex()
    if self.boxList[idx] == "JOINT":
      return True
    return False
    
  def isPose(self):
    idx = self.ui.comboBox.currentIndex()
    if self.boxList[idx] == "POSE":
      return True
    return False

  def isCustom(self):
    idx = self.ui.comboBox.currentIndex()
    if self.boxList[idx] == "CUSTOM":
      return True
    return False
    
  #**********************************
  #
  # Block signal
  #
  #**********************************
  def blockSignal(self, on):
    self.ui.doubleSpinBox.blockSignals(on)
    self.ui.doubleSpinBox_2.blockSignals(on)
    self.ui.doubleSpinBox_3.blockSignals(on)
    self.ui.doubleSpinBox_4.blockSignals(on)
    self.ui.doubleSpinBox_5.blockSignals(on)
    self.ui.doubleSpinBox_6.blockSignals(on)
    self.ui.doubleSpinBox_7.blockSignals(on)
    self.ui.doubleSpinBox_8.blockSignals(on)
    self.ui.horizontalSlider.blockSignals(on)
    self.ui.horizontalSlider_2.blockSignals(on)
    self.ui.horizontalSlider_3.blockSignals(on)
    self.ui.horizontalSlider_4.blockSignals(on)
    self.ui.horizontalSlider_5.blockSignals(on)
    self.ui.horizontalSlider_6.blockSignals(on)
    self.ui.horizontalSlider_7.blockSignals(on)
    self.ui.horizontalSlider_8.blockSignals(on)
  # ******************************
  #
  # SpinBox -> Slider
  #
  # ******************************
  def value_changed(self):
    self.blockSignal(True)
    self.ui.horizontalSlider.setValue(self.ui.doubleSpinBox.value()/self.ratio)
    self.ui.horizontalSlider_2.setValue(self.ui.doubleSpinBox_2.value()/self.ratio)
    self.ui.horizontalSlider_3.setValue(self.ui.doubleSpinBox_3.value()/self.ratio)
    self.ui.horizontalSlider_4.setValue(self.ui.doubleSpinBox_4.value()/self.ratio)
    self.ui.horizontalSlider_5.setValue(self.ui.doubleSpinBox_5.value()/self.ratio)
    self.ui.horizontalSlider_6.setValue(self.ui.doubleSpinBox_6.value()/self.ratio)
    self.ui.horizontalSlider_7.setValue(self.ui.doubleSpinBox_7.value()/self.ratio)
    self.ui.horizontalSlider_8.setValue(self.ui.doubleSpinBox_8.value()/self.ratio)
    self.blockSignal(False)

  # ******************************
  #
  # Slider -> SpinBox
  #
  # ******************************
  def value_changed2(self):
    self.blockSignal(True)
    self.ui.doubleSpinBox.setValue(self.ui.horizontalSlider.value()*self.ratio)
    self.ui.doubleSpinBox_2.setValue(self.ui.horizontalSlider_2.value()*self.ratio)
    self.ui.doubleSpinBox_3.setValue(self.ui.horizontalSlider_3.value()*self.ratio)
    self.ui.doubleSpinBox_4.setValue(self.ui.horizontalSlider_4.value()*self.ratio)
    self.ui.doubleSpinBox_5.setValue(self.ui.horizontalSlider_5.value()*self.ratio)
    self.ui.doubleSpinBox_6.setValue(self.ui.horizontalSlider_6.value()*self.ratio)
    self.ui.doubleSpinBox_7.setValue(self.ui.horizontalSlider_7.value()*self.ratio)
    self.ui.doubleSpinBox_8.setValue(self.ui.horizontalSlider_8.value()*self.ratio)
    self.blockSignal(False)
    
  #**********************************
  #
  # Label change (joint)
  #
  #**********************************
  def setLabel_joint(self):
    #url = QtCore.QUrl("/home")
    #QtGui.QDesktopServices.openUrl(url);

    self.ui.label.setText('<a href="/home">J1 [deg]</a>')
    self.ui.label.setOpenExternalLinks(True) 
    self.ui.label_2.setText('J2 [deg]')
    self.ui.label_3.setText('J3 [deg]')
    self.ui.label_4.setText('J4 [deg]')
    self.ui.label_5.setText('J5 [deg]')
    self.ui.label_6.setText('J6 [deg]')
    self.ui.label_7.setText('J7 [deg]')
    self.ui.label_8.setText('J8 [deg]')
    self.set_78_show(False)

  #**********************************
  #
  # Label change (pose)
  #
  #**********************************
  def setLabel_pose(self):
    self.ui.label.setText(' X  [mm]')
    self.ui.label_2.setText(' Y  [mm]')
    self.ui.label_3.setText(' Z  [mm]')
    self.ui.label_4.setText(' A [deg]')
    self.ui.label_5.setText(' B [deg]')
    self.ui.label_6.setText(' C [deg]')
    self.ui.label_7.setText('l1 [mm]')
    self.ui.label_8.setText('l2 [mm]')
    self.set_78_show(False)

  #**********************************
  #
  # Label change (custom)
  #
  #**********************************
  def setLabel_custom(self):
    self.ui.label.setText('D1 [mm]')
    self.ui.label_2.setText('P1 [deg]')
    self.ui.label_3.setText('T1 [deg]')
    self.ui.label_4.setText('D2 [mm]')
    self.ui.label_5.setText('P2 [deg]')
    self.ui.label_6.setText('T2 [deg]')
    self.ui.label_7.setText('<u>table</u>')
    self.ui.label_8.setText('θ [deg]')
    self.set_78_show(True)
    self.ui.horizontalSlider_7.hide()
    self.ui.doubleSpinBox_7.hide()

  #**********************************
  #
  # set shown axis number
  #
  #**********************************
  def set_78_show(self, on):
    if on:
      self.ui.label_7.show()
      self.ui.label_8.show()
      self.ui.doubleSpinBox_7.show()
      self.ui.doubleSpinBox_8.show()
      self.ui.horizontalSlider_7.show()
      self.ui.horizontalSlider_8.show()
    else:
      self.ui.label_7.hide()
      self.ui.label_8.hide()
      self.ui.doubleSpinBox_7.hide()
      self.ui.doubleSpinBox_8.hide()
      self.ui.horizontalSlider_7.hide()
      self.ui.horizontalSlider_8.hide()
    
  #**********************************
  #
  # get value
  #
  #**********************************
  def getValue(self):
    val = []
    val.append(self.ui.doubleSpinBox.value())
    val.append(self.ui.doubleSpinBox_2.value())
    val.append(self.ui.doubleSpinBox_3.value())
    val.append(self.ui.doubleSpinBox_4.value())
    val.append(self.ui.doubleSpinBox_5.value())
    val.append(self.ui.doubleSpinBox_6.value())
    val.append(self.ui.doubleSpinBox_7.value())
    val.append(self.ui.doubleSpinBox_8.value())
    return val
    
  #**********************************
  #
  # set value
  #
  #**********************************
  def setValue(self,val):
    if len(val)==8:
      self.blockSignal(True)
      self.ui.doubleSpinBox.setValue(val[0])
      self.ui.doubleSpinBox_2.setValue(val[1])
      self.ui.doubleSpinBox_3.setValue(val[2])
      self.ui.doubleSpinBox_4.setValue(val[3])
      self.ui.doubleSpinBox_5.setValue(val[4])
      self.ui.doubleSpinBox_6.setValue(val[5])
      self.ui.doubleSpinBox_7.setValue(val[6])
      self.ui.doubleSpinBox_8.setValue(val[7])
      self.value_changed()
      self.blockSignal(False) 

  #**********************************
  #
  # set JOINT
  #
  #**********************************
  def setJoint(self, val=None):
    #================================
    # set value
    #================================
    if val is None:
      val = self.val
    elif isinstance(val, str):
      val = str2float(val)
    
    if len(val)!=8:
      print "Wrong data size."
      return

    if self.isJoint():
      self.setValue(val)
    elif self.isPose():
      self.setValue(val)   
      self.ui.comboBox.setCurrentIndex(1) #POSE
      self.commboBox_change()

  #**********************************
  #
  # Set range and step size
  #
  #**********************************
  def setRange(self, Vmin=[0.0]*8, Vmax=[1.0]*8, Vstep=[0.01]*8):
    if (len(Vmin) == 8) and (len(Vmax) == 8) and (len(Vstep) == 8):
      setRange(self.ui.doubleSpinBox,   Vmin[0], Vmax[0], Vstep[0])
      setRange(self.ui.doubleSpinBox_2, Vmin[1], Vmax[1], Vstep[1])
      setRange(self.ui.doubleSpinBox_3, Vmin[2], Vmax[2], Vstep[2])
      setRange(self.ui.doubleSpinBox_4, Vmin[3], Vmax[3], Vstep[3])
      setRange(self.ui.doubleSpinBox_5, Vmin[4], Vmax[4], Vstep[4])
      setRange(self.ui.doubleSpinBox_6, Vmin[5], Vmax[5], Vstep[5])
      setRange(self.ui.doubleSpinBox_7, Vmin[6], Vmax[6], Vstep[6])
      setRange(self.ui.doubleSpinBox_8, Vmin[7], Vmax[7], Vstep[7])

      R = 1.0/self.ratio
      setRange(self.ui.horizontalSlider,   Vmin[0], Vmax[0], Vstep[0], R)
      setRange(self.ui.horizontalSlider_2, Vmin[1], Vmax[1], Vstep[1], R)
      setRange(self.ui.horizontalSlider_3, Vmin[2], Vmax[2], Vstep[2], R)
      setRange(self.ui.horizontalSlider_4, Vmin[3], Vmax[3], Vstep[3], R)
      setRange(self.ui.horizontalSlider_5, Vmin[4], Vmax[4], Vstep[4], R)
      setRange(self.ui.horizontalSlider_6, Vmin[5], Vmax[5], Vstep[5], R)
      setRange(self.ui.horizontalSlider_7, Vmin[6], Vmax[6], Vstep[6], R)
      setRange(self.ui.horizontalSlider_8, Vmin[7], Vmax[7], Vstep[7], R)
  
  #**********************************
  #
  # send value to parent
  #
  #**********************************
  def sendToParent(self, intype=0, outtype=0):
    #===========================
    # Request
    #===========================
    req = stateCmdRequest()
    req.mechno  = 1
    req.val     = self.getValue()
    req.flg     = self.flg
    req.inType  = intype      # 0:jnt 1:pos 
    req.outType = outtype     # 0:jnt 1:pos 

    print self.boxList[req.inType]+" ==> "+self.boxList[req.outType]

    #===========================
    # Response
    #===========================
    res = self.parent.sendToServer(req)
    if res.result==0: #OK
      self.val = list(res.val)
      self.flg = list(res.flg)
      return self.val
    else:             #NG
      self.setValue(self.val)
      return None
      
    
