# -*- coding: utf-8 -*-
#********************************
#  Qt
#********************************
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui
#********************************
#  Qt form
#********************************
import subform.RobotState.form as f1
import subform.RobotState.form2 as f2
#********************************
#  ROS
#********************************
from gui_sample.srv import *

#####################################
#
#	 Sub functions
#
#####################################
def setRange(ui, Vmin, Vmax, Vstep, ratio=1.0):
  ui.setRange(Vmin*ratio, Vmax*ratio)
  ui.setSingleStep(Vstep*ratio)
#####################################
#
# Sub form_manager
#
#####################################
class subform_manager(QDialog):
  def __init__(self, parent=None, init=[False]*3, pos=None):
  # ******************************
  #
  #  constructor
  #
  # ******************************
    super(subform_manager, self).__init__()
    self.parent = parent
    self.ui = f2.Ui_Dialog()
    self.ui.setupUi(self)
    
    self.ui.groupBox.setTitle("Above/Below")
    self.ui.groupBox_2.setTitle("Right/Left")
    self.ui.groupBox_3.setTitle("Flip/NonFlip")
    self.ui.radioButton.setText("Above")
    self.ui.radioButton_2.setText("Below")
    self.ui.radioButton_3.setText("Right")
    self.ui.radioButton_4.setText("Left")
    self.ui.radioButton_5.setText("Flip")
    self.ui.radioButton_6.setText("Nonflip")

    # set initial value
    if len(init) != 3:
      init = [False]*3
      
    if init[0]==False:
      self.ui.radioButton.setChecked(True)
    else:
      self.ui.radioButton_2.setChecked(True)
    if init[1]==False:
      self.ui.radioButton_3.setChecked(True)
    else:
      self.ui.radioButton_4.setChecked(True)
    if init[2]==False:
      self.ui.radioButton_5.setChecked(True)
    else:
      self.ui.radioButton_6.setChecked(True)

    self.setWindowFlags(QtCore.Qt.Popup)
    self.show()
    
    if pos is not None:
      self.move(pos)

  # ******************************
  #
  #  destructor
  #
  # ******************************
  def __del__(self):
    print "[subform_manager] delete subform_manager"

  # ******************************
  #
  #  close event
  #
  # ******************************
  def closeEvent(self,e):
    AB = self.ui.radioButton_2.isChecked()
    RL = self.ui.radioButton_4.isChecked()
    FN = self.ui.radioButton_6.isChecked()
    if self.parent is not None:
      self.parent.flg = [AB,RL,FN]
      self.parent.sendToParent(1,1)
#####################################
#
# form_manager
#
#  * parent must have [createSub] member
#
#####################################
class form_manager(QDialog):
  # ******************************
  #
  #  constructor
  #
  # ******************************
  def __init__(self, parent=None):
    super(form_manager, self).__init__()
    self.parent = parent  # Parent dialog
    self.ui = f1.Ui_Dialog()
    self.val = [0.0]*8
    self.flg = [False]*3
    self.dat = []
    self.mech = 0
  # ******************************
  #
  #  destructor
  #
  # ******************************
  def __del__(self):
    print "[form_manager] delete form_manager"

  # ******************************
  #
  #  stop UI
  #
  # ******************************
  def stopUi(self):
    self.parent.createSub = False
    
  # ******************************
  #
  #  preset UI
  #
  # ******************************
  def setupUi(self,Form):
    #	Cancel the top display setting of the parent dialog
    self.parent.setWindowFlag(QtCore.Qt.WindowStaysOnTopHint, False)
    self.parent.show()
    self.ui.setupUi(Form)

    # ==============================
    #  Qdialog setting
    # ==============================
    style = QApplication.instance().style()
    self.ratio = 0.01
    self.Form = Form             # f1 form    
    self.size = Form.size()
    self.sub = subform_manager() # f2 form
    
    self.boxList = ["JOINT","POSE"]

    self.txt = []
    self.txt.append( ['J1 [deg]',
                      'J2 [deg]',
                      'J3 [deg]', 
                      'J4 [deg]',
                      'J5 [deg]', 
                      'J6 [deg]',
                      'J7 [deg]', 
                      'J8 [deg]'])
    self.txt.append( [' X  [mm]', 
                      ' Y  [mm]', 
                      ' Z  [mm]', 
                      ' A [deg]',
                      ' B [deg]', 
                      ' C [deg]',
                      'l1  [mm]', 
                      'l2  [mm]'])
    # label
    self.label =   [ self.ui.label,
                     self.ui.label_2,
                     self.ui.label_3,
                     self.ui.label_4,
                     self.ui.label_5,
                     self.ui.label_6,
                     self.ui.label_7,
                     self.ui.label_8]
    # spinBox
    self.spinBox = [ self.ui.doubleSpinBox,
                     self.ui.doubleSpinBox_2,
                     self.ui.doubleSpinBox_3,
                     self.ui.doubleSpinBox_4,
                     self.ui.doubleSpinBox_5,
                     self.ui.doubleSpinBox_6,
                     self.ui.doubleSpinBox_7,
                     self.ui.doubleSpinBox_8]
    # slider
    self.slider =  [ self.ui.horizontalSlider,
                     self.ui.horizontalSlider_2,
                     self.ui.horizontalSlider_3,
                     self.ui.horizontalSlider_4,
                     self.ui.horizontalSlider_5,
                     self.ui.horizontalSlider_6,
                     self.ui.horizontalSlider_7,
                     self.ui.horizontalSlider_8]
    # button
    self.button =  [ self.ui.pushButton,
                     self.ui.pushButton_2,
                     self.ui.toolButton]
      
    for s in self.spinBox:
      s.valueChanged.connect(self.valueChanged)
    for s in self.slider:
      s.valueChanged.connect(self.valueChanged)

    # group box
    self.ui.groupBox.setTitle("")

    # comboBox
    self.ui.comboBox.activated.connect(self.commboBox_change)
    for i in self.boxList:
      self.ui.comboBox.addItem(i)

    # label
    self.setLabel(0)

    # button
    self.ui.pushButton.clicked.connect(self.reset_button_click)
    self.ui.pushButton.setText('Reset')
    self.ui.pushButton_2.clicked.connect(self.save_button_click)
    self.ui.pushButton_2.setText('Save')

    # tool button
    self.ui.toolButton.setToolTip('Flag config')
    self.ui.toolButton.setEnabled(False)
    self.ui.toolButton.clicked.connect(self.tool_click)

    # for 6 axis model
    self.ui.label_7.hide()
    self.ui.label_8.hide()
    self.ui.doubleSpinBox_7.hide()
    self.ui.doubleSpinBox_8.hide()
    self.ui.horizontalSlider_7.hide()
    self.ui.horizontalSlider_8.hide()

  #**********************************
  # (SIGNAL)
  # tool button clicked
  #
  #**********************************
  def tool_click(self):
    pos  = self.Form.pos()
    qPos = pos + QtCore.QPoint(0, self.size.height())
    self.sub = subform_manager(self, self.flg, qPos)
  #**********************************
  # (SIGNAL)
  # commboBox changed
  #
  #**********************************
  def commboBox_change(self):
    if self.isJoint():
      self.ui.toolButton.setEnabled(False)
      self.setLabel(0)
      self.sendToParent(1,0) # POSE -> JOINT
    elif self.isPose():
      self.ui.toolButton.setEnabled(True)
      self.setLabel(1)
      self.sendToParent(0,1) # JOINT -> POSE
    self.setValue(self.val)
  #**********************************
  # (SIGNAL)
  # doubleSpinBox Changed
  #
  #**********************************
  def doubleSpinChanged(self):
    self.spinBoxToSlider()   # SpinBox -> Slider
    if self.isJoint():
      self.sendToParent(0,0)
    elif self.isPose():
      self.sendToParent(1,1)
      
  #**********************************
  # (SIGNAL)
  # horizontalSliber Changed
  #
  #**********************************
  def sliderChanged(self):
    self.sliderToSpinBox() #  Slider -> SpinBox
    if self.isJoint():
      self.sendToParent(0,0)
    elif self.isPose():
      self.sendToParent(1,1)
      
  #**********************************
  # (SIGNAL)
  # value changed
  #
  #**********************************
  def valueChanged(self):
    obj = self.sender()
    for s in self.spinBox:
      if obj is s:
        self.spinBoxToSlider()
        return
    for s in self.slider:
      if obj is s:
        self.sliderToSpinBox()
        return
        
  #**********************************
  #
  # Get current comboBox type
  #
  #**********************************
  def isJoint(self):
    idx = self.ui.comboBox.currentIndex()
    if self.boxList[idx] == "JOINT":
      return True
    return False
    
  def isPose(self):
    idx = self.ui.comboBox.currentIndex()
    if self.boxList[idx] == "POSE":
      return True
    return False
    
  #**********************************
  #
  # Block signal
  #
  #**********************************
  def blockSignal(self, on):
    for s in self.spinBox:
      s.blockSignals(on)
    for s in self.slider:
      s.blockSignals(on)
      
  #**********************************
  #
  # SpinBox -> Slider
  #
  #**********************************
  def spinBoxToSlider(self):
    self.blockSignal(True)
    for i,s in enumerate(self.slider):
      s.setValue(self.spinBox[i].value()/self.ratio)
    self.blockSignal(False)

  #**********************************
  #
  # Slider -> SpinBox
  #
  #**********************************
  def sliderToSpinBox(self):
    self.blockSignal(True)
    for i,s in enumerate(self.spinBox):
      s.setValue(self.slider[i].value()*self.ratio)
    self.blockSignal(False)

  #**********************************
  #
  # set Label
  #
  #**********************************
  def setLabel(self, idx):
    for i,s in enumerate(self.label):
      s.setText(self.txt[idx][i])
      
  #**********************************
  #
  # Set range and step size
  #
  #**********************************
  def setRange(self, Vmin=[0.0]*8, Vmax=[1.0]*8, Vstep=[0.01]*8):
    if (len(Vmin) == 8) and (len(Vmax) == 8) and (len(Vstep) == 8):
      for i,s in enumerate(self.spinBox):
        setRange(s, Vmin[i], Vmax[i], Vstep[i])
      R = 1.0/self.ratio
      for i,s in enumerate(self.slider):
        setRange(s, Vmin[i], Vmax[i], Vstep[i], R)
        
  #**********************************
  #
  # get double spin box value
  #
  #**********************************
  def getValue(self):
    return [s.value() for s in self.spinBox]
    
  #**********************************
  #
  # set value to spinBox and slider
  #
  #**********************************
  def setValue(self,val):
    if len(val)==8:
      self.blockSignal(True)
      for i,s in enumerate(self.spinBox):
        s.setValue(val[i])
      self.spinBoxToSlider()
      self.blockSignal(False)
      
  #**********************************
  #
  # get JOINT
  #
  #**********************************
  def getJoint(self):
    pass
    
  #**********************************
  #
  # set JOINT
  #
  #**********************************
  def setJoint(self, val):
    if len(val)==8:
      if self.isJoint():
        self.setValue(val)
      elif self.isPose():
        self.setValue(val)
        self.ui.comboBox.setCurrentIndex(1) #POSE
        self.commboBox_change()
        
  #**********************************
  #
  # set DATA
  #
  #**********************************
  def setDATA(self, dat):
    self.dat = dat
    if dat.name == "robot1":
      self.mech = 0
      self.setJoint(dat.data["joint"])
    elif dat.name == "robot2":
      self.mech = 1
      self.setJoint(dat.data["joint"])
      
  # ******************************
  # (SIGNAL)
  # reset button clicked
  #
  # ******************************
  def reset_button_click(self):
    item = self.dat.getItem("joint")
    if item is not None:
      self.setJoint(item)
      
  # ******************************
  # (SIGNAL)
  # save button clicked
  #
  # ******************************
  def save_button_click(self):
    self.dat.setItem("joint", self.getValue())
    
  #**********************************
  #
  # send value to parent
  #
  #**********************************
  def sendToParent(self, intype=0, outtype=0):
    #===========================
    # Request
    #===========================
    req = stateCmdRequest()
    req.mechno  = 1
    req.val     = self.getValue()
    req.flg     = self.flg
    req.inType  = intype      # 0:jnt 1:pos 
    req.outType = outtype     # 0:jnt 1:pos 

    print self.boxList[req.inType]+" ==> "+self.boxList[req.outType]

    #===========================
    # Response
    #===========================
    res = self.parent.sendToServer(req)
    if res.result==0: #OK
      self.val = list(res.val)
      self.flg = list(res.flg)
      return self.val
    else:             #NG
      self.setValue(self.val)
      return None
      
    
