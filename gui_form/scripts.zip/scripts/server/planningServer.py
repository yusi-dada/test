#!/usr/bin/env python
# -*- coding: utf-8 -*-
##################################
#
#	 library
#
##################################
import os
import sys
import signal
import threading
import time
from math import pi
# ********************************
import rospy
from moveit_msgs.msg import PlanningScene
from moveit_msgs.msg import RobotState
from moveit_msgs.msg import DisplayTrajectory
from moveit_msgs.msg import RobotTrajectory

from std_msgs.msg import Header
from sensor_msgs.msg import JointState

import moveit_commander as mvit_cmd
import geometry_msgs.msg
import shape_msgs.msg
import tf

from gui_form.srv import *

############################################
#
#	 signal
#
############################################
def sigint_handler(*args):
  sys.exit()
############################################
#
# Threading
#
############################################
std_lock = threading.Lock()
class pub_thread(threading.Thread):
  def __init__(self,std_lock, master):
    super(pub_thread, self).__init__()
    self.daemon = True
    self.std_lock = std_lock
    self.pub_jnt  = rospy.Publisher('/joint_states2', JointState, queue_size=1)
    self.master   = master
    
  def run(self):
    while True:
      with self.std_lock:
        self.master.pub_joint.header = Header()
        self.master.pub_joint.header.stamp = rospy.Time.now()
        self.pub_jnt.publish(self.master.pub_joint)
      rospy.sleep(0.1)
      
############################################
#
# PlanningServer
#
############################################
class PlanningServer():
  ###################################################
  # constructor
  ###################################################
  def __init__(self, group):
    self.mechno = len(group)
    #self.robot = mvit_cmd.RobotCommander()
    #self.scene = mvit_cmd.PlanningSceneInterface()
    
    self.robotGroup = []
    self.initialPose = []
    #for i, name in enumerate(group):
    #  self.robotGroup.append(mvit_cmd.MoveGroupCommander(group[i]))
    #  self.initialPose.append([0,0,0,0,0,0])
        
    #
    # Publisher thread
    #
    self.pub_joint = JointState()
    self.th1 = pub_thread(std_lock,self)
    self.th1.start()

    #
    # Service server
    #
    s = rospy.Service('PlanningServer', planning, self.execute)

    print "[PlanningServer]"
  
  ###################################################
  # destructor
  ###################################################
  def __del__(self):
    print "delete Planning server"
  
  ###################################################
  # Planning command
  ###################################################
  def move_joint_to(self, mechno, jnt_goal):
    plan = self.robotGroup[mechno].plan(jnt_goal.position)
    return(plan)    
  
  ###################################################
  # Planning scene setting
  ###################################################
  # update joint
  def updateJoint(self, jnt):
    self.pub_joint.position = jnt

  # add_box
  def add_box(self, name, box_size, box_pose, timeout=4):
    s = (box_size.x,box_size.y,box_size.z)
    self.scene.add_box(name, box_pose, size=s)
    return self.wait_for_update(name,
                                box_is_known    = True,
                                box_is_attached = False,
                                timeout         = timeout)  
  # remove_box
  def remove_box(self, name, timeout=4):
    self.scene.remove_world_object(name)
    return self.wait_for_update(name, 
                                box_is_known    = False,
                                box_is_attached = False,
                                timeout         = timeout)   
  # wait for update
  def wait_for_update(self, name, box_is_known, box_is_attached, timeout):
    start = rospy.get_time()
    seconds = rospy.get_time()
    while(seconds - start < timeout) and not rospy.is_shutdown():
      attached_object = self.scene.get_attached_object([name])
      is_attached = len(attached_object.keys())>0
      is_known = name in self.scene.get_known_object_names()
      if(box_is_attached == is_attached) and (box_is_known == is_known):
        return True
      rospy.sleep(0.1)
      seconds = rospy.get_time()
    return False
    
  ###################################################
  # Execution
  ###################################################
  def execute(self,req):
    
    # update start position
    self.updateJoint(req.start)

    # update object
    for i,p in enumerate(req.pose):
      #self.add_box("box", req.vec3[i], p, timeout=4)
      print req.vec3[i]
      print p

    # planning command
    m = req.mechno
    g = req.goal
    print g

    rospy.sleep(0.1)
    print "execute!"

    # response    
    res = planningResponse()
    res.result = 1
    res.traj = DisplayTrajectory()
    
    return res

if __name__ == '__main__':
  rospy.init_node("planningServer",anonymous=True)
  signal.signal(signal.SIGINT, sigint_handler)
  rospy.sleep(3)
  mvit_cmd.roscpp_initialize(sys.argv)
  
  server = PlanningServer(["robot1","robot2"])
  
  rospy.spin()
    
    
    
