#! /usr/bin/python
# -*- coding: utf-8 -*-
# ********************************
#
#	 library
#
# ********************************
import rospy
import os
import sys
import signal
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui

from std_srvs.srv import *

import tf

# ********************************
#
#	 signal
#
# ********************************
def sigint_handler(*args):
  sys.exit()

# ********************************
#
#	 Service server
#
# ********************************
def dummyServer(req):
  rospy.sleep(0.1)

  return EmptyResponse()

# ********************************
#
#	 main
#
# ********************************
if __name__ == '__main__':
  rospy.init_node('dummyServer') 
  signal.signal(signal.SIGINT, sigint_handler)

  s = rospy.Service('dummyServer', Empty, dummyServer)
  print "ready"
  rospy.spin()

